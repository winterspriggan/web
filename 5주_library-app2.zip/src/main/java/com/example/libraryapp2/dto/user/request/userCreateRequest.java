package com.example.libraryapp2.dto.user.request;

public class userCreateRequest {

    private String name;
    private Integer age;


    public String getName() {
        return name;
    }

    public Integer getAge() {
        return age;
    }
}
