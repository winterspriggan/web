package com.example.libraryapp2.dto.user.request;

public class deleteUser
{
    String name;

    public String getName() {
        return name;
    }
}
